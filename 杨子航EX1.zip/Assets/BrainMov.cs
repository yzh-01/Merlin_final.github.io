using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BrainMov : MonoBehaviour
{
    public List<GameObject> objects; 
    public float speed = 10f; 
    public float scalespeed = 0.1f; 
    private float t = 1f;
    private List<Vector3> initialPositions;
     // Start is called before the first frame update
void Start()
    {
        if (objects.Count != 4)
        {
            Debug.LogError("Please add exactly 4 objects to the list");
            return;
        }

        // Initialize positions and scale
        initialPositions = new List<Vector3>
        {
            new Vector3(1, 1, 0),
            new Vector3(-1, 1, 0),
            new Vector3(-1, -1, 0),
            new Vector3(1, -1, 0)
        };

        for (int i = 0; i < objects.Count; i++)
        {
            if (objects[i] == null)
            {
                Debug.LogError("Object in the list is null");
                return;
            }
            objects[i].transform.position = initialPositions[i];
            objects[i].transform.localScale = Vector3.one;
        }
    }

    // Update is called once per frame
    void Update()
    {
       
        float p = 0f;

        if (Input.GetKey(KeyCode.UpArrow) || Input.GetKey(KeyCode.W))
        p = speed * Time.deltaTime;
        if (Input.GetKey(KeyCode.DownArrow) || Input.GetKey(KeyCode.S))
        p = -speed * Time.deltaTime;
        t +=p;
        t = Mathf.Clamp(t, 1f, 50f);
      for (int i=0;i<objects.Count;i++){
          objects[i].transform.position = initialPositions[i] * t;
      }
        float s = Input.GetAxis("Vertical")*scalespeed*Time.deltaTime;
         Vector3 size = new Vector3(s, s, s);
            foreach (GameObject obj in objects){
                obj.transform.localScale = Vector3.ClampMagnitude(
                obj.transform.localScale + size, 5f
            );
            obj.transform.localScale = Vector3.Max(
                obj.transform.localScale, 
                Vector3.one
            );
        }
          if (Input.GetKeyDown(KeyCode.Q))
        {
            Application.Quit();

        }   
    }

}
